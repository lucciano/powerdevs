#include "../../../boot/video-mode.c"
