#ifndef _ASM_X86_SCATTERLIST_H
#define _ASM_X86_SCATTERLIST_H

#define ISA_DMA_THRESHOLD (0x00ffffff)

#include <asm-generic/scatterlist.h>

#endif /* _ASM_X86_SCATTERLIST_H */
