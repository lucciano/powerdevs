#ifndef _ASM_X86_XEN_GRANT_TABLE_H
#define _ASM_X86_XEN_GRANT_TABLE_H

#define xen_alloc_vm_area(size)	alloc_vm_area(size)
#define xen_free_vm_area(area)	free_vm_area(area)

#endif /* _ASM_X86_XEN_GRANT_TABLE_H */
