#ifndef _ASM_X86_SECTIONS_H
#define _ASM_X86_SECTIONS_H

#include <asm-generic/sections.h>

extern char __brk_base[], __brk_limit[];

#endif	/* _ASM_X86_SECTIONS_H */
