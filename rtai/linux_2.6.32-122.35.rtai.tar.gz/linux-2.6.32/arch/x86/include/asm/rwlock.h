#ifndef _ASM_X86_RWLOCK_H
#define _ASM_X86_RWLOCK_H

#define RW_LOCK_BIAS		 0x01000000

/* Actual code is in asm/spinlock.h or in arch/x86/lib/rwlock.S */

#endif /* _ASM_X86_RWLOCK_H */
