#include <linux/module.h>
#include <asm/msr.h>

EXPORT_SYMBOL(native_rdmsr_safe_regs);
EXPORT_SYMBOL(native_wrmsr_safe_regs);
